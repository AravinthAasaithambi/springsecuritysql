package spring.security.spring_security;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerSS {

    @GetMapping("/")
    public String home(){
        return "<h1>Welcome to home page!</h1>";
    }

    @GetMapping("/admin")
    public String admin() {
        return "<h1>Admin Works!</h1>";
    }

    @GetMapping("/user")
    public String user() {
        return "<h1>User Works!</h1>";
    }

    @GetMapping("/superadmin")
    public String superadmin(){
        return "<h1>Superadmin Works!</h1>";
    }

}
